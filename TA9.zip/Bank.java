import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.TreeSet;

public class Bank {
	public Bank(){	
	}
	
	/*
	 * Option 1: Bank
	 */
	TreeSet<Customer> customers = new TreeSet<Customer>();

	public void addCustomer(Customer c){
		customers.add(c);
	}

	public Customer[] getCustomers(){
		Customer[] cus = new Customer[customers.size()];
		customers.toArray(cus);
		return cus;
	}

	/*
	 * Option 2: Bank
	 */
	private PriorityQueue<Customer> queuedCustomers = new PriorityQueue<Customer>(new CustomerPriorityComparator());
	
	public void queueCustomer(Customer toAdd){
		queuedCustomers.add(toAdd);
	}

	public Customer nextCustomer(){
		Customer result;
		try{
			result = new Customer(queuedCustomers.poll());
		} catch (NullPointerException npe){
			result = null;
		}
		return result;
	}
	
	/*
	 * Option 3: Bank
	 */
	private HashSet<BankAccount> accounts = new HashSet<BankAccount>();
	
	public void addAccount(BankAccount aAccount) throws DuplicateAccountException{
		if (accounts.add(aAccount)){
		} else {
			throw new DuplicateAccountException();
		}
	}
	
	public BankAccount[] getAccounts(){
		BankAccount[] ba = new BankAccount[accounts.size()];
		accounts.toArray(ba);
		return ba;
	}
}
