import java.util.Comparator;

public class CustomerPriorityComparator implements Comparator<Customer>{
	
	public int compare(Customer aCustomerOne, Customer aCustomerTwo){
		int result = 0;
		if (aCustomerOne.getCreditHistory().getCreditRating() < aCustomerTwo.getCreditHistory().getCreditRating()){
			result = 1;
		} else if (aCustomerOne.getCreditHistory().getCreditRating() == aCustomerTwo.getCreditHistory().getCreditRating()){
			result = 0;
		} else if (aCustomerOne.getCreditHistory().getCreditRating() > aCustomerTwo.getCreditHistory().getCreditRating()){
			result = -1;
		}
		return result;
	}
}
