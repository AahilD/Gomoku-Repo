rm -r /home/$(whoami)/Gomoku/
rm /home/$(whoami)/Desktop/Gomoku.desktop
