usrname=""$(whoami)
launchername="Gomoku.desktop"
installpath="/home/$usrname/"
desktoppath=$installpath"Desktop/"
curPath=$(pwd)

mv "$curPath" "$installpath"

mv $installpath"Gomoku/"$launchername $desktoppath"Gomoku.desktop"

sed -i "s/manu/$usrname/g" "/home/$usrname/Desktop/Gomoku.desktop"
