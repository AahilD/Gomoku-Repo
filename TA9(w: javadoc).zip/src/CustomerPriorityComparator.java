import java.util.Comparator;
public class CustomerPriorityComparator implements Comparator<Customer>{
	
	
	/**
	 * @param Takes in two variables of type Customer
	 * @return When the first customer's credit rating is less than the second's a 1 is returned, 
	 * 			when the credit ratings are the same a 0 is given back, and if the the first's credit 
	 * 			rating is greater than the second's a 1 is returned
	 */
	public int compare(Customer aCustomerOne, Customer aCustomerTwo){
		int result = 0;
		if (aCustomerOne.getCreditHistory().getCreditRating() < aCustomerTwo.getCreditHistory().getCreditRating()){
			result = 1;
		} else if (aCustomerOne.getCreditHistory().getCreditRating() == aCustomerTwo.getCreditHistory().getCreditRating()){
			result = 0;
		} else if (aCustomerOne.getCreditHistory().getCreditRating() > aCustomerTwo.getCreditHistory().getCreditRating()){
			result = -1;
		}
		return result;
	}
}
