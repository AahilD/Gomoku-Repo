public class Customer implements Comparable<Customer>{
	private String name = "";
	private int id = 0;
	private CreditHistory history;
	public static int numOfCustomers = 0;
	public Customer()
	{
		
	}
	
	public Customer(Customer oldCustomer)
	{
		name = oldCustomer.getName();
		id = oldCustomer.getID();
	}
	
	
	public Customer(String aName, int anID){
		name = aName;
		id = anID;
	}
	
	public void setName(String aName) {
		name = aName;
	}
	
	public String getName(){
		return name;
	}
	
	public void setID(int newID)
	{
		id = newID;
	}
	
	public int getID() {
		return id;
	}
	
	
	public String toString()
	{
		return name + ' ' + id;
	}
	
	public void setCreditHistory(CreditHistory aHistory) {
		history = aHistory;
	}
	
	public CreditHistory getCreditHistory(){
		return history;
	}

	public static int getNumOfCustomers(){
		int counter = numOfCustomers;
		numOfCustomers = 0;
		return counter;
	}
	
	public static void setNumOfCustomers(){
		numOfCustomers++;
	}

	/**
	 * @param Takes a customer as an argument to use when comparing
	 * @return As a result a 0 is returned if the argument is the same, 1 is given back if name is the same but id 
	 * 			is less than when compared or when the name is not the same and the id is less than when compared, 
	 * 			and a -1 is returned when name is the same but id is greater than when compared or when the name 
	 * 			is not the same and the id is greater than when compared
	 */
	public int compareTo(Customer arg) {
		int num = 0;
		
		if (name == arg.getName()){
			if (id == arg.getID()){
				num = 0;
			}
			else if ( id > arg.getID()){
				num = 1;
			} else {
				num = -1;
			}
		} else {
			for (int i = 0; i < name.length() && i < arg.getName().length(); i ++) {
				if ((int)name.charAt(i) == (int)arg.getName().charAt(i)) { 
					continue; 
				} else if ((int)name.charAt(i) > (int)arg.getName().charAt(i)){ 
					num = 1;  
					break;
	                
				} else if ((int)name.charAt(i) < (int)arg.getName().charAt(i)){
					num = -1;
					break;
				}
			}
		}
		return num;
	}
}
