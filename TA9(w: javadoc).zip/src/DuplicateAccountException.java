
public class DuplicateAccountException extends Exception {
	
}
