rm -r $(pwd)
rm /home/$(whoami)/Desktop/Gomoku.desktop
